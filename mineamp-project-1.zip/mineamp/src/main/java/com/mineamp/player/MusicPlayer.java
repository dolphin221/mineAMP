package com.mineamp.player;

import com.mineamp.audio.MusicFolder;
import com.mineamp.audio.VoiceChatSender;
import com.mineamp.audio.WavPlayer;

import java.nio.file.Path;
import java.util.List;

/**
 * Singleton that manages the current playlist and playback state.
 * Used by both the GUI and the /mineamp commands.
 */
public class MusicPlayer {

    private static MusicPlayer instance;

    private List<String> playlist;
    private int currentIndex = 0;
    private WavPlayer currentPlayer;
    private boolean paused = false;

    private MusicPlayer() {
        playlist = MusicFolder.listTracks();
    }

    public static MusicPlayer getInstance() {
        if (instance == null) instance = new MusicPlayer();
        return instance;
    }

    public void refreshPlaylist() {
        playlist = MusicFolder.listTracks();
    }

    public List<String> getPlaylist() {
        return playlist;
    }

    public int getCurrentIndex() {
        return currentIndex;
    }

    public String getCurrentTrackName() {
        if (playlist.isEmpty()) return null;
        return playlist.get(currentIndex);
    }

    public boolean isPlaying() {
        return currentPlayer != null && currentPlayer.isPlaying();
    }

    public boolean isPaused() {
        return paused;
    }

    public float getProgress() {
        if (currentPlayer == null) return 0f;
        return currentPlayer.getProgress();
    }

    /** Play a track by filename */
    public boolean play(String filename) {
        Path track = MusicFolder.getTrack(filename);
        if (track == null) return false;

        stopInternal();
        int idx = playlist.indexOf(filename);
        if (idx >= 0) currentIndex = idx;

        currentPlayer = new WavPlayer(track);
        currentPlayer.start();
        paused = false;
        return true;
    }

    /** Play current track in playlist */
    public boolean play() {
        if (playlist.isEmpty()) return false;
        return play(playlist.get(currentIndex));
    }

    public void stop() {
        stopInternal();
        paused = false;
        VoiceChatSender.getInstance().closeChannel();
    }

    public void next() {
        if (playlist.isEmpty()) return;
        currentIndex = (currentIndex + 1) % playlist.size();
        play();
    }

    public void prev() {
        if (playlist.isEmpty()) return;
        currentIndex = (currentIndex - 1 + playlist.size()) % playlist.size();
        play();
    }

    private void stopInternal() {
        if (currentPlayer != null) {
            currentPlayer.stop();
            currentPlayer = null;
        }
    }
}
