package com.mineamp.gui;

import com.mineamp.audio.MusicFolder;
import com.mineamp.player.MusicPlayer;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.util.Identifier;

import java.util.List;

/**
 * The Winamp Playlist Editor window.
 * Renders below the main player window.
 *
 * Uses playlist.png as background texture.
 * Tracks are listed with green text on dark background — classic Winamp style.
 */
public class PlaylistWindow {

    private static final Identifier TEX_PLAYLIST = Identifier.of("mineamp", "textures/gui/playlist.png");

    // Playlist window dimensions (Winamp standard)
    private static final int PL_W = 275;
    private static final int PL_H = 116;

    private final int x;
    private final int y;
    private final int width;
    private final int height;

    // Scroll offset (track index of first visible track)
    private int scrollOffset = 0;
    private static final int VISIBLE_TRACKS = 10;
    private static final int TRACK_H = 10;

    public PlaylistWindow(int x, int y, int width, int height) {
        this.x = x;
        this.y = y;
        this.width = PL_W;
        this.height = PL_H;
    }

    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        // Black background
        context.fill(x, y, x + width, y + height, 0xFF000000);

        // Draw playlist.png background texture
        context.drawTexture(
            net.minecraft.client.render.RenderLayer::getGuiTextured,
            TEX_PLAYLIST,
            x, y,
            0, 0,
            width, height,
            width, height
        );

        // Draw track list
        List<String> tracks = MusicFolder.listTracks();
        int currentIdx = MusicPlayer.getInstance().getCurrentIndex();
        var textRenderer = MinecraftClient.getInstance().textRenderer;

        int listX = x + 12;
        int listY = y + 20;

        for (int i = scrollOffset; i < Math.min(tracks.size(), scrollOffset + VISIBLE_TRACKS); i++) {
            String name = tracks.get(i);
            // Remove .wav extension
            String display = name.toLowerCase().endsWith(".wav") ? name.substring(0, name.length() - 4) : name;
            // Truncate long names
            if (display.length() > 30) display = display.substring(0, 30);

            boolean isCurrent = (i == currentIdx);
            int color = isCurrent ? 0xFFFFFFFF : 0xFF00C800; // white if current, green otherwise

            // Track number
            context.drawText(textRenderer, (i + 1) + ". " + display.toUpperCase(),
                listX, listY + (i - scrollOffset) * TRACK_H, color, false);
        }

        // Draw "no tracks" message if empty
        if (tracks.isEmpty()) {
            context.drawText(textRenderer, "NO TRACKS IN .minecraft/mineamp/music/",
                listX, listY, 0xFF888888, false);
        }
    }

    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        // Click on a track to play it
        if (mouseX < x || mouseX > x + width || mouseY < y + 20 || mouseY > y + height) {
            return false;
        }

        int relY = (int)(mouseY - (y + 20));
        int clickedIdx = scrollOffset + (relY / TRACK_H);
        List<String> tracks = MusicFolder.listTracks();

        if (clickedIdx >= 0 && clickedIdx < tracks.size()) {
            MusicPlayer.getInstance().play(tracks.get(clickedIdx));
            return true;
        }
        return false;
    }

    public boolean mouseScrolled(double mouseX, double mouseY, double amount) {
        List<String> tracks = MusicFolder.listTracks();
        if (amount < 0) {
            scrollOffset = Math.min(scrollOffset + 1, Math.max(0, tracks.size() - VISIBLE_TRACKS));
        } else {
            scrollOffset = Math.max(0, scrollOffset - 1);
        }
        return true;
    }
}
