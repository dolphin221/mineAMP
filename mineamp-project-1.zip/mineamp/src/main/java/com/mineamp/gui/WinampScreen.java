package com.mineamp.gui;

import com.mineamp.player.MusicPlayer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;

/**
 * Main Winamp GUI screen.
 *
 * Layout based on Alien-ated skin (2002).
 * Window size: 275x116 px (main player)
 *
 * Texture atlas layout (replace placeholder PNGs with real skin files):
 *   main.png      - background of the entire player window
 *   titlebar.png  - top title bar
 *   buttons.png   - prev/play/pause/stop/next buttons (spritesheet)
 *   posbar.png    - position/progress bar track + thumb
 *   volume.png    - volume slider
 *   balance.png   - balance slider
 *   numbers.png   - digit font (0-9) for time display
 *   monoster.png  - mono/stereo indicator
 *   playpaus.png  - play/pause/stop indicator lamp
 *   shufrep.png   - shuffle/repeat toggle buttons
 */
public class WinampScreen extends Screen {

    // Winamp main window dimensions (original skin resolution)
    private static final int WIN_W = 275;
    private static final int WIN_H = 116;

    // Texture identifiers
    private static final Identifier TEX_MAIN     = Identifier.of("mineamp", "textures/gui/main.png");
    private static final Identifier TEX_TITLEBAR = Identifier.of("mineamp", "textures/gui/titlebar.png");
    private static final Identifier TEX_BUTTONS  = Identifier.of("mineamp", "textures/gui/buttons.png");
    private static final Identifier TEX_POSBAR   = Identifier.of("mineamp", "textures/gui/posbar.png");
    private static final Identifier TEX_VOLUME   = Identifier.of("mineamp", "textures/gui/volume.png");
    private static final Identifier TEX_NUMBERS  = Identifier.of("mineamp", "textures/gui/numbers.png");
    private static final Identifier TEX_PLAYPAUS = Identifier.of("mineamp", "textures/gui/playpaus.png");
    private static final Identifier TEX_SHUFREP  = Identifier.of("mineamp", "textures/gui/shufrep.png");

    // Button regions in buttons.png spritesheet (x, y, w, h) — classic Winamp layout
    // These match the standard Winamp 2.x skin spec
    private static final int BTN_W = 23;
    private static final int BTN_H = 18;

    // Screen offset (centered)
    private int originX;
    private int originY;

    // Playlist window
    private PlaylistWindow playlistWindow;

    // Volume: 0-100
    private int volume = 75;
    private boolean draggingVolume = false;

    // Position bar dragging
    private boolean draggingPos = false;

    public WinampScreen() {
        super(Text.literal("MineAMP"));
    }

    @Override
    protected void init() {
        // Center the window on screen
        originX = (this.width - WIN_W) / 2;
        originY = (this.height - WIN_H) / 2;

        // Add control buttons
        addWinampButtons();

        // Init playlist window below main player
        playlistWindow = new PlaylistWindow(originX, originY + WIN_H + 2, WIN_W, 116);
    }

    private void addWinampButtons() {
        MusicPlayer player = MusicPlayer.getInstance();

        // PREV button — x=16, y=88 in Winamp skin
        addDrawableChild(new WinampButton(
            originX + 16, originY + 88, BTN_W, BTN_H,
            TEX_BUTTONS, 0, 0, 0, 18, // normal / hovered UV in spritesheet
            "PREV",
            btn -> player.prev()
        ));

        // PLAY button
        addDrawableChild(new WinampButton(
            originX + 39, originY + 88, BTN_W, BTN_H,
            TEX_BUTTONS, 23, 0, 23, 18,
            "PLAY",
            btn -> player.play()
        ));

        // PAUSE button
        addDrawableChild(new WinampButton(
            originX + 62, originY + 88, BTN_W, BTN_H,
            TEX_BUTTONS, 46, 0, 46, 18,
            "PAUSE",
            btn -> {
                // TODO: implement pause in WavPlayer
                player.stop();
            }
        ));

        // STOP button
        addDrawableChild(new WinampButton(
            originX + 85, originY + 88, BTN_W, BTN_H,
            TEX_BUTTONS, 69, 0, 69, 18,
            "STOP",
            btn -> player.stop()
        ));

        // NEXT button
        addDrawableChild(new WinampButton(
            originX + 108, originY + 88, BTN_W, BTN_H,
            TEX_BUTTONS, 92, 0, 92, 18,
            "NEXT",
            btn -> player.next()
        ));

        // EJECT / Open playlist button
        addDrawableChild(new WinampButton(
            originX + 136, originY + 88, 22, BTN_H,
            TEX_BUTTONS, 114, 0, 114, 18,
            "EJECT",
            btn -> {} // open file dialog — future feature
        ));
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        // Draw dark background behind window
        context.fill(originX - 2, originY - 2, originX + WIN_W + 2, originY + WIN_H + 2, 0xFF000000);

        // Draw main skin background
        context.drawTexture(
            net.minecraft.client.render.RenderLayer::getGuiTextured,
            TEX_MAIN,
            originX, originY,
            0, 0,
            WIN_W, WIN_H,
            WIN_W, WIN_H
        );

        // Draw title bar
        context.drawTexture(
            net.minecraft.client.render.RenderLayer::getGuiTextured,
            TEX_TITLEBAR,
            originX, originY,
            0, 0,
            WIN_W, 14,
            WIN_W, 14
        );

        // Draw song title text (scrolling marquee — simplified)
        renderSongTitle(context);

        // Draw time display
        renderTimeDisplay(context);

        // Draw position bar
        renderPositionBar(context, mouseX, mouseY);

        // Draw volume slider
        renderVolumeSlider(context, mouseX, mouseY);

        // Draw play/pause indicator
        renderPlayIndicator(context);

        // Draw playlist window
        if (playlistWindow != null) {
            playlistWindow.render(context, mouseX, mouseY, delta);
        }

        // Render buttons
        super.render(context, mouseX, mouseY, delta);
    }

    private void renderSongTitle(DrawContext context) {
        MusicPlayer player = MusicPlayer.getInstance();
        String title = player.getCurrentTrackName();
        if (title == null) title = "--- MineAMP ---";
        // Remove .wav extension for display
        if (title.toLowerCase().endsWith(".wav")) title = title.substring(0, title.length() - 4);

        // Classic Winamp song title area: x=111, y=27, width=155
        // Simple scrolling: truncate for now
        int maxChars = 25;
        if (title.length() > maxChars) title = title.substring(0, maxChars);

        // Draw with green color to match Winamp LCD look
        context.drawText(
            this.textRenderer,
            title.toUpperCase(),
            originX + 111, originY + 27,
            0xFF00FF00, // classic Winamp green
            false
        );
    }

    private void renderTimeDisplay(DrawContext context) {
        MusicPlayer player = MusicPlayer.getInstance();

        // Calculate elapsed time from progress (approximate)
        // TODO: track real elapsed seconds in WavPlayer
        String timeStr = "0:00";

        // Draw using numbers.png digit font
        // For now draw as text in LCD green style
        context.drawText(
            this.textRenderer,
            timeStr,
            originX + 36, originY + 26,
            0xFF00FF00,
            false
        );
    }

    private void renderPositionBar(DrawContext context, int mouseX, int mouseY) {
        // Position bar: x=16, y=72, width=248, height=10
        int barX = originX + 16;
        int barY = originY + 72;
        int barW = 248;
        int barH = 10;

        // Draw bar track
        context.drawTexture(
            net.minecraft.client.render.RenderLayer::getGuiTextured,
            TEX_POSBAR,
            barX, barY,
            0, 0,
            barW, barH,
            barW, barH
        );

        // Draw thumb at current position
        float progress = MusicPlayer.getInstance().getProgress();
        int thumbX = barX + (int)(progress * (barW - 29));

        context.drawTexture(
            net.minecraft.client.render.RenderLayer::getGuiTextured,
            TEX_POSBAR,
            thumbX, barY,
            0, 10, // thumb is below bar track in posbar.png
            29, 10,
            248, 20
        );
    }

    private void renderVolumeSlider(DrawContext context, int mouseX, int mouseY) {
        // Volume slider area: x=107, y=57, width=68, height=13
        int sliderX = originX + 107;
        int sliderY = originY + 57;
        int sliderW = 68;

        context.drawTexture(
            net.minecraft.client.render.RenderLayer::getGuiTextured,
            TEX_VOLUME,
            sliderX, sliderY,
            0, 0,
            sliderW, 13,
            sliderW, 26
        );

        // Draw knob
        int knobX = sliderX + (int)((volume / 100f) * (sliderW - 14));
        context.drawTexture(
            net.minecraft.client.render.RenderLayer::getGuiTextured,
            TEX_VOLUME,
            knobX, sliderY,
            0, 13,
            14, 11,
            sliderW, 26
        );
    }

    private void renderPlayIndicator(DrawContext context) {
        // Play/pause lamp indicator: x=24, y=28 — small icon
        MusicPlayer player = MusicPlayer.getInstance();
        // 0=stop, 1=play, 2=pause in playpaus.png
        int stateOffset = player.isPlaying() ? 1 : 0;

        context.drawTexture(
            net.minecraft.client.render.RenderLayer::getGuiTextured,
            TEX_PLAYPAUS,
            originX + 24, originY + 28,
            stateOffset * 9, 0,
            9, 9,
            27, 9
        );
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        // Check position bar click
        int barX = originX + 16;
        int barY = originY + 72;
        int barW = 248;
        if (mouseX >= barX && mouseX <= barX + barW && mouseY >= barY && mouseY <= barY + 10) {
            draggingPos = true;
            // TODO: seek to position
        }

        // Check volume slider click
        int volX = originX + 107;
        int volY = originY + 57;
        if (mouseX >= volX && mouseX <= volX + 68 && mouseY >= volY && mouseY <= volY + 13) {
            draggingVolume = true;
            volume = (int)(((mouseX - volX) / 68f) * 100);
            volume = Math.max(0, Math.min(100, volume));
        }

        // Playlist window clicks
        if (playlistWindow != null) {
            playlistWindow.mouseClicked(mouseX, mouseY, button);
        }

        return super.mouseClicked(mouseX, mouseY, button);
    }

    @Override
    public boolean mouseDragged(double mouseX, double mouseY, int button, double deltaX, double deltaY) {
        if (draggingVolume) {
            int volX = originX + 107;
            volume = (int)(((mouseX - volX) / 68f) * 100);
            volume = Math.max(0, Math.min(100, volume));
        }
        return super.mouseDragged(mouseX, mouseY, button, deltaX, deltaY);
    }

    @Override
    public boolean mouseReleased(double mouseX, double mouseY, int button) {
        draggingVolume = false;
        draggingPos = false;
        return super.mouseReleased(mouseX, mouseY, button);
    }

    @Override
    public boolean shouldPause() {
        // Don't pause the game when GUI is open
        return false;
    }

    @Override
    public boolean shouldCloseOnEsc() {
        return true;
    }
}
