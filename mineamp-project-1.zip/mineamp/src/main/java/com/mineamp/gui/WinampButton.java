package com.mineamp.gui;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;

import java.util.function.Consumer;

/**
 * A button that renders from a spritesheet texture (like Winamp skin buttons).
 *
 * normalU/normalV   = UV coords in texture when button is idle
 * hoveredU/hoveredV = UV coords in texture when button is hovered/pressed
 */
public class WinampButton extends ButtonWidget {

    private final Identifier texture;
    private final int normalU;
    private final int normalV;
    private final int hoveredU;
    private final int hoveredV;
    private final int texW;
    private final int texH;

    public WinampButton(
        int x, int y, int width, int height,
        Identifier texture,
        int normalU, int normalV,
        int hoveredU, int hoveredV,
        String tooltip,
        Consumer<WinampButton> onPress
    ) {
        super(x, y, width, height, Text.literal(tooltip), btn -> onPress.accept((WinampButton) btn), DEFAULT_NARRATION_SUPPLIER);
        this.texture = texture;
        this.normalU = normalU;
        this.normalV = normalV;
        this.hoveredU = hoveredU;
        this.hoveredV = hoveredV;
        // Assume spritesheet is wide enough; standard Winamp buttons.bmp is 161x108
        this.texW = 161;
        this.texH = 108;
    }

    @Override
    public void renderWidget(DrawContext context, int mouseX, int mouseY, float delta) {
        boolean hovered = isHovered();
        int u = hovered ? hoveredU : normalU;
        int v = hovered ? hoveredV : normalV;

        context.drawTexture(
            net.minecraft.client.render.RenderLayer::getGuiTextured,
            texture,
            getX(), getY(),
            u, v,
            getWidth(), getHeight(),
            texW, texH
        );
    }
}
