package com.mineamp.command;

import com.mineamp.audio.MusicFolder;
import com.mineamp.gui.WinampScreen;
import com.mineamp.player.MusicPlayer;
import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.context.CommandContext;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandManager;
import net.fabricmc.fabric.api.client.command.v2.FabricClientCommandSource;
import net.minecraft.client.MinecraftClient;
import net.minecraft.text.Text;

import java.util.List;

public class MineAmpCommand {

    public static void register(CommandDispatcher<FabricClientCommandSource> dispatcher) {

        dispatcher.register(
            ClientCommandManager.literal("mineamp")
                // /mineamp → open GUI
                .executes(MineAmpCommand::openGui)

                // /mineamp play <filename>
                .then(ClientCommandManager.literal("play")
                    .then(ClientCommandManager.argument("file", StringArgumentType.greedyString())
                        .executes(ctx -> {
                            String file = StringArgumentType.getString(ctx, "file");
                            return playTrack(ctx, file);
                        })
                    )
                    // /mineamp play (resume current)
                    .executes(ctx -> playTrack(ctx, null))
                )

                // /mineamp stop
                .then(ClientCommandManager.literal("stop")
                    .executes(MineAmpCommand::stop)
                )

                // /mineamp list
                .then(ClientCommandManager.literal("list")
                    .executes(MineAmpCommand::listTracks)
                )

                // /mineamp next
                .then(ClientCommandManager.literal("next")
                    .executes(MineAmpCommand::next)
                )

                // /mineamp prev
                .then(ClientCommandManager.literal("prev")
                    .executes(MineAmpCommand::prev)
                )
        );
    }

    private static int openGui(CommandContext<FabricClientCommandSource> ctx) {
        MinecraftClient.getInstance().execute(() ->
            MinecraftClient.getInstance().setScreen(new WinampScreen())
        );
        return 1;
    }

    private static int playTrack(CommandContext<FabricClientCommandSource> ctx, String file) {
        MusicPlayer player = MusicPlayer.getInstance();
        boolean ok;
        if (file == null) {
            ok = player.play();
        } else {
            ok = player.play(file);
        }
        if (ok) {
            ctx.getSource().sendFeedback(
                Text.literal("§a▶ Playing: §f" + player.getCurrentTrackName())
            );
        } else {
            ctx.getSource().sendFeedback(
                Text.literal("§cTrack not found. Use /mineamp list to see available tracks.")
            );
        }
        return ok ? 1 : 0;
    }

    private static int stop(CommandContext<FabricClientCommandSource> ctx) {
        MusicPlayer.getInstance().stop();
        ctx.getSource().sendFeedback(Text.literal("§c■ Stopped."));
        return 1;
    }

    private static int listTracks(CommandContext<FabricClientCommandSource> ctx) {
        List<String> tracks = MusicFolder.listTracks();
        if (tracks.isEmpty()) {
            ctx.getSource().sendFeedback(
                Text.literal("§eNo tracks found in .minecraft/mineamp/music/")
            );
        } else {
            ctx.getSource().sendFeedback(Text.literal("§6=== MineAMP Playlist ==="));
            for (int i = 0; i < tracks.size(); i++) {
                ctx.getSource().sendFeedback(
                    Text.literal("§7" + (i + 1) + ". §f" + tracks.get(i))
                );
            }
        }
        return 1;
    }

    private static int next(CommandContext<FabricClientCommandSource> ctx) {
        MusicPlayer.getInstance().next();
        ctx.getSource().sendFeedback(
            Text.literal("§a⏭ Now playing: §f" + MusicPlayer.getInstance().getCurrentTrackName())
        );
        return 1;
    }

    private static int prev(CommandContext<FabricClientCommandSource> ctx) {
        MusicPlayer.getInstance().prev();
        ctx.getSource().sendFeedback(
            Text.literal("§a⏮ Now playing: §f" + MusicPlayer.getInstance().getCurrentTrackName())
        );
        return 1;
    }
}
