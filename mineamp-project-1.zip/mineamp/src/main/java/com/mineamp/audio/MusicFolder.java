package com.mineamp.audio;

import com.mineamp.MineAmpClient;
import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;

public class MusicFolder {

    private static Path musicDir;

    public static void init() {
        Path gameDir = FabricLoader.getInstance().getGameDir();
        musicDir = gameDir.resolve("mineamp").resolve("music");
        if (!Files.exists(musicDir)) {
            try {
                Files.createDirectories(musicDir);
                MineAmpClient.LOGGER.info("Created music folder: {}", musicDir);
            } catch (IOException e) {
                MineAmpClient.LOGGER.error("Failed to create music folder", e);
            }
        }
    }

    public static Path getMusicDir() {
        return musicDir;
    }

    /**
     * Returns a list of all .wav filenames in the music folder.
     */
    public static List<String> listTracks() {
        List<String> tracks = new ArrayList<>();
        if (musicDir == null || !Files.exists(musicDir)) return tracks;
        try (var stream = Files.list(musicDir)) {
            stream
                .filter(p -> p.toString().toLowerCase().endsWith(".wav"))
                .map(p -> p.getFileName().toString())
                .sorted()
                .forEach(tracks::add);
        } catch (IOException e) {
            MineAmpClient.LOGGER.error("Failed to list tracks", e);
        }
        return tracks;
    }

    /**
     * Returns the full Path to a track by filename, or null if not found.
     */
    public static Path getTrack(String filename) {
        Path track = musicDir.resolve(filename);
        if (Files.exists(track)) return track;
        return null;
    }
}
