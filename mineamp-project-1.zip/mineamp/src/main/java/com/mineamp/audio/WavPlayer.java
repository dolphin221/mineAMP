package com.mineamp.audio;

import com.mineamp.MineAmpClient;

import javax.sound.sampled.*;
import java.io.IOException;
import java.nio.file.Path;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * Plays a WAV file by reading PCM frames and pushing them
 * to Simple Voice Chat via VoiceChatSender.
 *
 * Required WAV format: PCM signed 16-bit, mono, 48000 Hz.
 *
 * Usage:
 *   WavPlayer player = new WavPlayer(path);
 *   player.start();
 *   // ...
 *   player.stop();
 */
public class WavPlayer {

    // Simple Voice Chat sends audio in 960-sample frames at 48kHz (20ms)
    private static final int FRAME_SIZE = 960;
    private static final int SAMPLE_RATE = 48000;
    private static final int BYTES_PER_SAMPLE = 2; // 16-bit
    private static final int FRAME_BYTES = FRAME_SIZE * BYTES_PER_SAMPLE;

    private final Path wavPath;
    private final AtomicBoolean running = new AtomicBoolean(false);
    private Thread playbackThread;

    // State for GUI progress tracking
    private volatile int totalFrames = 0;
    private volatile int currentFrame = 0;
    private volatile boolean finished = false;

    public WavPlayer(Path wavPath) {
        this.wavPath = wavPath;
    }

    public void start() {
        if (running.get()) stop();
        running.set(true);
        finished = false;
        currentFrame = 0;

        playbackThread = new Thread(this::playbackLoop, "MineAMP-Playback");
        playbackThread.setDaemon(true);
        playbackThread.start();
    }

    public void stop() {
        running.set(false);
        if (playbackThread != null) {
            playbackThread.interrupt();
            playbackThread = null;
        }
        finished = true;
    }

    public boolean isPlaying() {
        return running.get();
    }

    public boolean isFinished() {
        return finished;
    }

    /** 0.0 to 1.0 progress */
    public float getProgress() {
        if (totalFrames == 0) return 0f;
        return (float) currentFrame / totalFrames;
    }

    private void playbackLoop() {
        try (AudioInputStream raw = AudioSystem.getAudioInputStream(wavPath.toFile())) {
            AudioFormat sourceFormat = raw.getFormat();
            AudioFormat targetFormat = new AudioFormat(
                AudioFormat.Encoding.PCM_SIGNED,
                SAMPLE_RATE,
                16,
                1,
                BYTES_PER_SAMPLE,
                SAMPLE_RATE,
                false
            );

            AudioInputStream pcmStream;
            if (!formatsCompatible(sourceFormat, targetFormat)) {
                MineAmpClient.LOGGER.warn(
                    "Converting audio: {} -> {}", sourceFormat, targetFormat
                );
                pcmStream = AudioSystem.getAudioInputStream(targetFormat, raw);
            } else {
                pcmStream = raw;
            }

            long totalBytes = pcmStream.getFrameLength() * BYTES_PER_SAMPLE;
            totalFrames = (int) (totalBytes / FRAME_BYTES);

            byte[] buffer = new byte[FRAME_BYTES];
            int bytesRead;

            // Get the Voice Chat sender (injected at runtime)
            VoiceChatSender sender = VoiceChatSender.getInstance();

            while (running.get()) {
                bytesRead = pcmStream.read(buffer, 0, FRAME_BYTES);
                if (bytesRead == -1) break;

                // If short read, pad with silence
                if (bytesRead < FRAME_BYTES) {
                    for (int i = bytesRead; i < FRAME_BYTES; i++) buffer[i] = 0;
                }

                short[] samples = bytesToShorts(buffer);

                if (sender != null) {
                    sender.sendAudioFrame(samples);
                }

                currentFrame++;

                // Sleep to maintain 20ms frame timing
                try {
                    Thread.sleep(20);
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                    break;
                }
            }

            pcmStream.close();
        } catch (UnsupportedAudioFileException e) {
            MineAmpClient.LOGGER.error("Unsupported audio file: {}", wavPath, e);
        } catch (IOException e) {
            MineAmpClient.LOGGER.error("IO error during playback: {}", wavPath, e);
        } finally {
            running.set(false);
            finished = true;
        }
    }

    private static boolean formatsCompatible(AudioFormat a, AudioFormat b) {
        return a.getSampleRate() == b.getSampleRate()
            && a.getChannels() == b.getChannels()
            && a.getSampleSizeInBits() == b.getSampleSizeInBits()
            && a.getEncoding() == b.getEncoding();
    }

    private static short[] bytesToShorts(byte[] bytes) {
        short[] shorts = new short[bytes.length / 2];
        for (int i = 0; i < shorts.length; i++) {
            shorts[i] = (short) ((bytes[i * 2] & 0xFF) | (bytes[i * 2 + 1] << 8));
        }
        return shorts;
    }
}
