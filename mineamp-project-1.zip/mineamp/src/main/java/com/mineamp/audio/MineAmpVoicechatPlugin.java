package com.mineamp.audio;

import com.mineamp.MineAmpClient;
import de.maxhenkel.voicechat.api.VoicechatClientApi;
import de.maxhenkel.voicechat.api.VoicechatPlugin;
import de.maxhenkel.voicechat.api.events.ClientVoicechatConnectionEvent;
import de.maxhenkel.voicechat.api.events.EventRegistration;

/**
 * Registers MineAMP as a Simple Voice Chat plugin.
 * Must be declared in fabric.mod.json under "custom" -> "voicechat:plugins".
 */
public class MineAmpVoicechatPlugin implements VoicechatPlugin {

    public static final String PLUGIN_ID = "mineamp";

    @Override
    public String getPluginId() {
        return PLUGIN_ID;
    }

    @Override
    public void initialize(VoicechatClientApi api) {
        MineAmpClient.LOGGER.info("MineAMP Voice Chat plugin initialized");
        VoiceChatSender.getInstance().setApi(api);
    }

    @Override
    public void registerEvents(EventRegistration registration) {
        registration.registerEvent(ClientVoicechatConnectionEvent.class, this::onConnect);
    }

    private void onConnect(ClientVoicechatConnectionEvent event) {
        MineAmpClient.LOGGER.info("Connected to voice chat server");
    }
}
