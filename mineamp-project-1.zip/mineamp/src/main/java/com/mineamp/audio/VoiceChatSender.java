package com.mineamp.audio;

import com.mineamp.MineAmpClient;
import de.maxhenkel.voicechat.api.VoicechatConnection;
import de.maxhenkel.voicechat.api.audiochannel.AudioChannel;
import de.maxhenkel.voicechat.api.audiochannel.LocationalAudioChannel;
import de.maxhenkel.voicechat.api.VoicechatClientApi;

/**
 * Singleton bridge between WavPlayer and Simple Voice Chat.
 *
 * Simple Voice Chat sends audio as short[] arrays (PCM signed 16-bit, 48kHz, mono).
 * Each frame = 960 samples = 20ms of audio.
 *
 * This class is initialized by MineAmpVoicechatPlugin when Voice Chat is available.
 */
public class VoiceChatSender {

    private static VoiceChatSender instance;

    private VoicechatClientApi api;
    private AudioChannel channel;

    private VoiceChatSender() {}

    public static VoiceChatSender getInstance() {
        if (instance == null) {
            instance = new VoiceChatSender();
        }
        return instance;
    }

    public void setApi(VoicechatClientApi api) {
        this.api = api;
    }

    /**
     * Opens a static (non-positional) audio channel.
     * Use this for a global music broadcast.
     */
    public void openStaticChannel() {
        if (api == null) {
            MineAmpClient.LOGGER.warn("Voice Chat API not available");
            return;
        }
        try {
            channel = api.createStaticAudioChannel(
                java.util.UUID.randomUUID(),
                api.fromClientLevel(net.minecraft.client.MinecraftClient.getInstance().world),
                api.fromClientPlayer(net.minecraft.client.MinecraftClient.getInstance().player)
            );
            MineAmpClient.LOGGER.info("Opened static audio channel");
        } catch (Exception e) {
            MineAmpClient.LOGGER.error("Failed to open audio channel", e);
        }
    }

    /**
     * Sends one 20ms audio frame (960 samples) to Voice Chat.
     */
    public void sendAudioFrame(short[] samples) {
        if (channel == null) {
            openStaticChannel();
        }
        if (channel != null) {
            channel.send(samples);
        }
    }

    public void closeChannel() {
        if (channel != null) {
            channel.flush();
            channel = null;
        }
    }

    public boolean isReady() {
        return api != null;
    }
}
